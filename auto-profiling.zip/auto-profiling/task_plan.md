# Task Plan

## Goal

Upgrade `auto-profiling` into a long-running harness that uses `aim.md`, `uv`, git-friendly artifacts, planner-generator-evaluator style handoffs, and persistent markdown state without drifting off task.

Also provide system-level onboarding docs:

- English README
- Chinese README
- Chinese `aim.md` template
- clear explanation of the relationship between `auto-profiling` and `inference-opt-skill`

## Phases

| Phase | Status | Notes |
| --- | --- | --- |
| inspect current project | complete | reviewed runtime, skills, and current doc gaps |
| design runtime contract | complete | README structure and relationship explanation were planned before writing |
| write failing tests | complete | existing runtime tests remain valid for this doc-focused iteration |
| implement runtime | complete | English README, Chinese README, and Chinese aim template added |
| verify and package | complete | docs validated and diagnostics remain clean |

## Constraints

- exact-parity mode remains the default
- bounded tolerance is allowed only for declared cross-device or precision transitions
- runtime stays minimal and stdlib-first
- `aim.md` remains the primary human control surface
- logs and progress files must be easy to inspect in git
