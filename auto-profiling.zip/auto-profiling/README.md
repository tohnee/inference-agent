# Auto-Profiling

Auto-Profiling is a long-running inference optimization harness built on top of the local skills in this workspace.

It is designed for the following workflow:

- the human provides environment, baseline code, and verification commands
- the human edits only `aim.md`
- the runtime initializes a git-friendly workspace under `.auto-profiling/`
- the agent runs bounded experiments, evaluates them, keeps or rejects them, and writes handoff artifacts for the next iteration

The default philosophy is:

- exact-parity first
- performance second
- one bounded experiment at a time
- skeptical evaluation instead of self-congratulation

## What This Project Contains

### Runtime

- `runner.py`: executes the `aim.md` contract
- `scorer.py`: compares reference and candidate results
- `pyproject.toml`: enables `uv` execution
- `log_schema.json`: structured log schema

### Human Control Surface

- `aim.md`: the only required human-edited runtime contract
- `aim.zh-CN.md`: Chinese version of the same template

### Harness State

The runtime creates and updates `.auto-profiling/` in the target repository:

- `experiment_log.md`
- `experiment_log.jsonl`
- `baseline_snapshot.json`
- `best_result.json`
- `session_state.json`
- `current_contract.md`
- `evaluator_report.md`
- `next_handoff.md`
- `task_plan.md`
- `findings.md`
- `progress.md`
- `worklog.md`

### Reference Guides

- `references/01_operating_model.md`
- `references/02_experiment_loop.md`
- `references/03_mutation_lanes.md`
- `references/04_exactness_gate.md`
- `references/05_artifacts_and_scoring.md`
- `references/06_harness_patterns.md`

## Core Architecture

Auto-Profiling uses a planner-generator-evaluator style harness, but keeps the runtime minimal.

### Planner Role

The planner role is represented by:

- `aim.md`
- `.auto-profiling/current_contract.md`

This is where the current objective, exactness mode, selected lane, and experiment boundary are written down.

### Generator Role

The generator role is the actual bounded optimization attempt:

- run baseline
- apply one candidate change
- rerun exactness checks
- rerun measurement

The runtime itself does not hardcode a mutation engine. It provides the loop, state, and artifacts so Claude can mutate code while staying bounded.

### Evaluator Role

The evaluator role is separated from generation through:

- `scorer.py`
- `.auto-profiling/evaluator_report.md`

The evaluator decides whether a candidate should be kept based on:

- exactness
- metric improvement
- scope compliance
- stability
- reproducibility

This prevents the system from blindly praising its own changes.

### Handoff Role

Long-running work is stabilized through:

- `.auto-profiling/session_state.json`
- `.auto-profiling/next_handoff.md`

These files make it possible to resume in a fresh session without depending on a huge conversation history.

## Exactness Model

### 1. Exact-Parity Mode

This is the default mode.

Use it when:

- logic is unchanged
- algorithm is unchanged
- device class is effectively the same
- numerical contract is unchanged

Rule:

- any output mismatch fails the experiment

### 2. Bounded-Tolerance Mode

Use it only when all are true:

- logic remains equivalent
- algorithm remains equivalent
- the difference comes from declared cross-device execution or declared precision transitions
- `abs_tolerance` and `rel_tolerance` are explicitly set in `aim.md`

Example:

- CPU reference vs GPU candidate
- FP32 reference vs BF16 candidate

Rule:

- exceed either tolerance and the experiment fails
- if logic or algorithm equivalence fails, tolerance mode does not save the run

## Runtime Commands

Run from this directory with `uv`.

### Initialize

```bash
uv run runner.py init --aim aim.md
```

Creates or refreshes the runtime workspace and handoff scaffolding.

### Capture Baseline

```bash
uv run runner.py baseline --aim aim.md
```

Runs the trusted path, records exactness and performance, and stores the baseline snapshot.

### Evaluate A Candidate

```bash
uv run runner.py candidate --aim aim.md --label exp-001
```

Runs a bounded candidate experiment and promotes it if it beats the current reference under the exactness contract.

### Evaluate Without Promotion

```bash
uv run runner.py evaluate --aim aim.md --label eval-001
```

Runs the same evaluation path but does not promote the candidate to best-known result.

### Long-Running Loop Step

```bash
uv run runner.py loop --aim aim.md --label loop-001
```

Runs one resumable harness step:

- if no baseline exists, it creates one
- otherwise it runs a candidate step against the current best reference

### Read Current Status

```bash
uv run runner.py status --aim aim.md
```

Shows:

- baseline availability
- best result availability
- current session state
- workspace paths

### Produce A Handoff

```bash
uv run runner.py handoff --aim aim.md
```

Writes and prints the next handoff summary for a resumed session.

## How To Fill `aim.md`

The minimum required fields are:

- `target_repo_path`
- `baseline_run_command`
- `baseline_profile_command`
- `metric_output_path`
- `exactness_output_path`
- `exactness_check_command`
- `target_metric_name`
- `target_metric_direction`

Strongly recommended fields:

- `allowed_mutations`
- `blocked_by_default`
- `known_bottlenecks`
- `suspected_safe_lanes`
- `max_iterations_per_session`
- `max_runtime_per_experiment`

## Expected Output Files

Your commands should write machine-readable JSON for:

### Metric payload

Example:

```json
{
  "metrics": {
    "p95_ms": 8.4,
    "throughput": 120.0
  }
}
```

### Exactness payload

Exact-parity example:

```json
{
  "passed": true,
  "mismatch_count": 0
}
```

Bounded-tolerance example:

```json
{
  "passed": false,
  "logic_equivalent": true,
  "algorithm_equivalent": true,
  "mismatch_count": 3,
  "max_abs_error": 0.000004,
  "max_rel_error": 0.000003
}
```

The runtime computes the final exactness decision based on the mode declared in `aim.md`.

## Relationship To `inference-opt-skill`

`inference-opt-skill` and `auto-profiling` are complementary, not redundant.

### `inference-opt-skill`

Path:

- [inference-opt-skill](file:///Users/tc/Downloads/推理优化skills/inference-opt-skill)

Role:

- the optimization knowledge base
- the methodology playbook
- the routing system for baseline, profiling, roofline, memory, parallelism, cache, and deployment

It tells you **what to analyze** and **which optimization lane makes sense**.

### `auto-profiling`

Path:

- [auto-profiling](file:///Users/tc/Downloads/推理优化skills/auto-profiling)

Role:

- the orchestration harness
- the runtime loop
- the artifact manager
- the keep-or-revert execution engine

It tells you **how to run repeated optimization iterations safely and continuously**.

### Practical Relationship

Use them together like this:

1. use `inference-opt-skill` to understand the bottleneck and select a safe lane
2. encode the project contract in `auto-profiling/aim.md`
3. run `auto-profiling` to execute bounded experiments and preserve state
4. use the reference docs from `inference-opt-skill` when choosing the next mutation lane

In short:

- `inference-opt-skill` = optimization brain
- `auto-profiling` = optimization harness

## Recommended Workflow

1. prepare a runnable baseline repository
2. fill `aim.md`
3. run `uv run runner.py init --aim aim.md`
4. run `uv run runner.py baseline --aim aim.md`
5. inspect `.auto-profiling/current_contract.md`
6. run one bounded candidate step
7. read `.auto-profiling/evaluator_report.md`
8. use `.auto-profiling/next_handoff.md` to continue the next session

## Common Mistakes

- treating tolerance mode as a shortcut for logic changes
- changing multiple variables in one experiment
- failing to provide JSON metric and exactness outputs
- skipping baseline and trying to optimize immediately
- forgetting that `auto-profiling` needs `inference-opt-skill` for optimization strategy guidance

## Suggested Next Improvements

If you continue evolving this project, the most natural next steps are:

- automatic multi-round loop execution
- automatic contract generation from profiler evidence
- richer evaluator rubric
- lane-specific helpers that directly import the logic of `inference-opt-skill`
