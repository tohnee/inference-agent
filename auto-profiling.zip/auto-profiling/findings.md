# Findings

## Current Observations

- `auto-profiling` already defines the orchestration protocol but has no executable runtime.
- The human-edited contract is `aim.md`, so the runtime must parse markdown reliably without introducing a second required config format.
- The runtime needs a keep-or-revert scorer that prefers exactness over metric gains.
- The runtime should initialize `.auto-profiling/` artifacts so the agent can append progress instead of inventing file layouts per repo.
- `uv` is a good fit because the runtime can stay stdlib-only and still be easy to run.
- A runnable minimal runtime can stay stdlib-only if the contract requires metric and exactness commands to emit JSON files.
- Git-aware progress artifacts are easiest to review when markdown summaries and JSONL machine logs are both kept under `.auto-profiling/`.
- Long-running harnesses stay coherent longer when they use structured handoff artifacts instead of relying on a single growing context window.
- Separating planner, generator, and evaluator roles reduces self-congratulation and makes keep-or-revert decisions more skeptical and reliable.
- The evaluator needs explicit, gradable criteria; for this project that means exactness, metric improvement, scope compliance, stability, and reproducibility.
- Exact-parity should remain the default mode, but bounded tolerance is legitimate for declared cross-device or precision transitions when logic and algorithm remain equivalent and numeric error stays within contract.
- A practical long-running harness for profiling does not need full multi-agent orchestration in the runtime itself if it persists planner contracts, evaluator reports, and handoff files on disk.
- Comparing against the current best result, not only the original baseline, makes iterative promotion more faithful to long-running optimization loops.
- The biggest onboarding gap in the current project was not runtime capability but lack of a system-level README explaining architecture, usage, and the relationship to `inference-opt-skill`.
- A Chinese `aim.md` template is useful because the operating contract is the file humans touch most often, so localization here has higher leverage than translating every internal artifact.
