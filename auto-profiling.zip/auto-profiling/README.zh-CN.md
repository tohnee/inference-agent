# Auto-Profiling

Auto-Profiling 是构建在本地 skills 之上的一个长运行推理优化 harness。

它面向这样的使用方式：

- 人类提供环境、baseline 代码和验证命令
- 人类只编辑 `aim.md`
- runtime 在目标仓库下初始化 `.auto-profiling/` 工作区
- agent 以“单轮单变量实验”的方式持续执行、评估、保留或回滚，并把下一轮 handoff 写到磁盘

默认哲学是：

- 结果一致优先
- 性能改进其次
- 每轮只做一个有边界的实验
- 评估必须独立、怀疑，而不是自我表扬

## 项目包含什么

### Runtime

- `runner.py`：执行 `aim.md` 契约
- `scorer.py`：统一比较 reference 与 candidate
- `pyproject.toml`：支持 `uv`
- `log_schema.json`：结构化日志 schema

### 人类控制面

- `aim.md`：唯一必填的人类运行契约
- `aim.zh-CN.md`：中文版模板

### Harness 状态目录

runtime 会在目标仓库中创建并维护 `.auto-profiling/`：

- `experiment_log.md`
- `experiment_log.jsonl`
- `baseline_snapshot.json`
- `best_result.json`
- `session_state.json`
- `current_contract.md`
- `evaluator_report.md`
- `next_handoff.md`
- `task_plan.md`
- `findings.md`
- `progress.md`
- `worklog.md`

### 参考文档

- `references/01_operating_model.md`
- `references/02_experiment_loop.md`
- `references/03_mutation_lanes.md`
- `references/04_exactness_gate.md`
- `references/05_artifacts_and_scoring.md`
- `references/06_harness_patterns.md`

## 架构总览

Auto-Profiling 采用 planner / generator / evaluator 风格的 harness 思想，但 runtime 保持尽量轻量。

### Planner 角色

Planner 角色通过以下文件体现：

- `aim.md`
- `.auto-profiling/current_contract.md`

这里负责写清楚当前目标、exactness mode、选定的 mutation lane，以及本轮实验边界。

### Generator 角色

Generator 角色就是实际的有边界优化尝试：

- 跑 baseline
- 应用一处 candidate change
- 先重跑 exactness
- 再重跑性能测量

runtime 本身不把“变异引擎”写死。它负责提供循环、状态和工件，让 Claude 能在受控边界里改代码。

### Evaluator 角色

Evaluator 角色通过以下部分与 generator 分离：

- `scorer.py`
- `.auto-profiling/evaluator_report.md`

Evaluator 是否保留当前候选，依据的是：

- exactness
- metric 是否提升
- 是否越界修改
- 稳定性
- 可复现性

这样可以避免系统一边做改动，一边对自己过度乐观。

### Handoff 角色

长时间运行时，依靠这些文件保持连续性：

- `.auto-profiling/session_state.json`
- `.auto-profiling/next_handoff.md`

这样即使你换一个新 session，也可以从磁盘恢复，而不依赖超长上下文。

## Exactness 模型

### 1. Exact-Parity 模式

这是默认模式。

适用条件：

- 逻辑不变
- 算法不变
- 设备类别基本一致
- 数值契约不变

规则：

- 任何输出不一致都判定失败

### 2. Bounded-Tolerance 模式

只有在以下条件都满足时才允许使用：

- 逻辑等价
- 算法等价
- 差异来自已声明的跨设备执行或 precision 切换
- `aim.md` 中明确声明了 `abs_tolerance` 和 `rel_tolerance`

典型场景：

- CPU reference vs GPU candidate
- FP32 reference vs BF16 candidate

规则：

- 任何一个误差阈值超出都失败
- 如果逻辑或算法本身不等价，容差模式不能“洗白”这个实验

## Runtime 命令

在本目录下用 `uv` 运行。

### 初始化

```bash
uv run runner.py init --aim aim.md
```

创建或刷新 runtime workspace 与 handoff 骨架。

### 记录 Baseline

```bash
uv run runner.py baseline --aim aim.md
```

运行可信路径，记录 exactness 与性能，并保存 baseline snapshot。

### 评估一个 Candidate

```bash
uv run runner.py candidate --aim aim.md --label exp-001
```

执行一轮有边界 candidate 实验；如果它在 exactness 契约下优于当前 reference，就会被提升为新的 best。

### 只评估不晋升

```bash
uv run runner.py evaluate --aim aim.md --label eval-001
```

执行同样的评估逻辑，但不会把 candidate 晋升为 best-known result。

### Long-Running Loop 单步执行

```bash
uv run runner.py loop --aim aim.md --label loop-001
```

执行一个可恢复的 harness step：

- 如果还没有 baseline，就先创建 baseline
- 否则基于当前 best reference 跑一轮 candidate

### 查看状态

```bash
uv run runner.py status --aim aim.md
```

显示：

- baseline 是否存在
- best result 是否存在
- 当前 session state
- workspace 路径

### 生成 Handoff

```bash
uv run runner.py handoff --aim aim.md
```

写出并打印下一轮 resume 所需的 handoff 摘要。

## 如何填写 `aim.md`

最少需要这些字段：

- `target_repo_path`
- `baseline_run_command`
- `baseline_profile_command`
- `metric_output_path`
- `exactness_output_path`
- `exactness_check_command`
- `target_metric_name`
- `target_metric_direction`

强烈建议填写：

- `allowed_mutations`
- `blocked_by_default`
- `known_bottlenecks`
- `suspected_safe_lanes`
- `max_iterations_per_session`
- `max_runtime_per_experiment`

## 你的命令应输出什么

你的 baseline / candidate 命令需要输出机器可读 JSON。

### Metric payload

示例：

```json
{
  "metrics": {
    "p95_ms": 8.4,
    "throughput": 120.0
  }
}
```

### Exactness payload

Exact-parity 示例：

```json
{
  "passed": true,
  "mismatch_count": 0
}
```

Bounded-tolerance 示例：

```json
{
  "passed": false,
  "logic_equivalent": true,
  "algorithm_equivalent": true,
  "mismatch_count": 3,
  "max_abs_error": 0.000004,
  "max_rel_error": 0.000003
}
```

最终 exactness 是否通过，由 runtime 根据 `aim.md` 中声明的模式统一判断。

## 它和 `inference-opt-skill` 是什么关系

`inference-opt-skill` 和 `auto-profiling` 是互补关系，不是重复关系。

### `inference-opt-skill`

路径：

- [inference-opt-skill](file:///Users/tc/Downloads/推理优化skills/inference-opt-skill)

职责：

- 推理优化知识库
- 系统方法论
- baseline / profiling / roofline / memory / parallelism / cache / deployment 的路由手册

它回答的是：

- 该分析什么
- 该走哪条优化路线

### `auto-profiling`

路径：

- [auto-profiling](file:///Users/tc/Downloads/推理优化skills/auto-profiling)

职责：

- 编排 harness
- runtime 循环
- 工件管理
- keep-or-revert 执行引擎

它回答的是：

- 如何安全地、持续地、可恢复地跑优化实验

### 实际协作方式

一起使用时建议这样：

1. 用 `inference-opt-skill` 判断瓶颈和合理的优化 lane
2. 在 `auto-profiling/aim.md` 中写清楚项目契约
3. 用 `auto-profiling` 执行有边界实验并保存状态
4. 下一轮 mutation lane 选择时，再回到 `inference-opt-skill` 的 reference 文档

一句话总结：

- `inference-opt-skill` = 优化大脑
- `auto-profiling` = 优化 harness

## 推荐使用流程

1. 准备一个可运行的 baseline 仓库
2. 填写 `aim.md`
3. 执行 `uv run runner.py init --aim aim.md`
4. 执行 `uv run runner.py baseline --aim aim.md`
5. 阅读 `.auto-profiling/current_contract.md`
6. 执行一轮 bounded candidate
7. 阅读 `.auto-profiling/evaluator_report.md`
8. 用 `.auto-profiling/next_handoff.md` 进入下一轮 session

## 常见错误

- 把 tolerance mode 当作逻辑改动的豁免
- 一轮实验改太多变量
- 没有输出 JSON metric / exactness 文件
- 没跑 baseline 就开始优化
- 忘记 `auto-profiling` 需要 `inference-opt-skill` 提供优化策略脑图

## 建议的下一步增强

如果你继续演进这个项目，最自然的后续方向是：

- 自动多轮 loop
- 根据 profiler 证据自动生成 contract
- 更细粒度 evaluator rubric
- 直接把 `inference-opt-skill` 的 lane 知识接入 runtime 帮助器
